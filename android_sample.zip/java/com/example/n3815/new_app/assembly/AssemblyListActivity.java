package com.example.n3815.new_app.assembly;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.n3815.new_app.MainActivity;
import com.example.n3815.new_app.R;
import com.example.n3815.new_app.common.DefaultRestClient;
import com.example.n3815.new_app.common.bean.AssemBean;
import com.example.n3815.new_app.common.bean.Items;

import java.io.IOException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by N3815 on 2016-12-19.
 */
public class AssemblyListActivity extends MainActivity implements AbsListView.OnScrollListener {
    // http://apis.data.go.kr/9710000/NationalAssemblyInfoService/getMemberCurrStateList?serviceKey=q1p5TosEhgURKtNouuTaxt4aOX0yu55kVUa%2FZIizv2tdjIG5WARFe7ET02PNGyPThekktyx12SZ9GBSjkwti8A%3D%3D&pageNo=4

    public int PAGE = 1;
    public void setPage(int page){
        this.PAGE = page;
    }

    ListView listview;          // 리스트뷰 객체
    AssemblyListAdapter adapter;      // 아이템을 셋팅해줄 Adapter 객체
    ArrayList<AssemBean> list_itemArrayList = new ArrayList<AssemBean>();    // 객체를 담고 있을꾸야

    DefaultRestClient<AssemblyService> assemblyRestClient;  // restAPI
    AssemblyService assemblyService;    // Url service

    boolean lastitemVisibleFlag = false;		//화면에 리스트의 마지막 아이템이 보여지는지 체크

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assem_list);

        // custom adapter 생성
        adapter = new AssemblyListAdapter();
        listview = (ListView) findViewById(R.id.assembly_listView);

        // 첫 1페이지일 경우에만 호출
        if(PAGE == 1){
            try {
                AssemblyList(PAGE);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        listview.setAdapter(adapter);
        listview.setOnScrollListener(this); // 리스트뷰에 OnScrollListener를 설정

        // 아이템 클릭시
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                // Toast.makeText(AssemblyListActivity.this ,list_itemArrayList.get(position).getEmpNm(),Toast.LENGTH_LONG).show();

                // 이동
                Intent intent = new Intent(AssemblyListActivity.this, AssemblyDetailActivity.class);
                intent.putExtra("numOfRows",20); // 한페이지 결과수
                intent.putExtra("pageNo",PAGE); // 페이지
                intent.putExtra("dept_cd",list_itemArrayList.get(position).getDeptCd()); // 부서코드
                intent.putExtra("num",list_itemArrayList.get(position).getNum()); // 국회의원 번호
                intent.putExtra("jpgLink",list_itemArrayList.get(position).getJpgLink()); // 사진
                intent.putExtra("empNm",list_itemArrayList.get(position).getEmpNm()); // 국회의원 이름
                startActivity(intent);
            }
        });
    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount)
    {
        // 스크롤 행위에 대한 콜백 메소드
        if(view.isShown()){
            // 마지막 아이템에 닿았을 경우, 페이지 추가 로드
            if(totalItemCount != 0 && (firstVisibleItem+visibleItemCount) == totalItemCount && lastitemVisibleFlag == false) {
                try {
                    AssemblyList(PAGE+1);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public void onScrollStateChanged(AbsListView absListView, int i){
        // 상태에 대한 콜백 메소드
    }

    /*
     * 국회의원 정보 가져오기
     */
    public void AssemblyList(
        int page
    ) throws IOException {
        final ArrayList<AssemBean> assemInfo = new ArrayList<AssemBean>();

        assemblyRestClient = new DefaultRestClient<>();
        assemblyService = assemblyRestClient.getAssemblyClient(AssemblyService.class);

        // 아이템을 추가하는 동안 중복 요청을 방지하기 위해 락을 걸어둡니다.
        lastitemVisibleFlag = true;
        setPage(page);  // 페이지 설정

        Call<Items> call = assemblyService.getMemberCurrStateList(page);
        call.enqueue(new Callback<Items>() {
            @Override
            public void onResponse(Call<Items> call, Response<Items> response) {
                try{
                    if(response.isSuccessful()){
                        // 해당 객체에 담기
                        for(AssemBean userInfo : response.body().getItems()){
                            adapter.addItem(userInfo.getJpgLink(), userInfo.getEmpNm(), userInfo.getOrigNm());
                            list_itemArrayList.add(userInfo);
                        }
                        adapter.notifyDataSetChanged();

                        // 다시 호출할 수 있도록 false 처리
                        lastitemVisibleFlag = false;
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<Items> call, Throwable throwable) {
                throwable.printStackTrace();
            }
        });
    }
}
